# 🎂 Age Calculator

A modern Android app that calculates your exact age in years, months and days, plus total months, weeks, days, hours, minutes, next-birthday countdown, birth weekday and zodiac sign.

Built with **Kotlin** and **Jetpack Compose (Material 3)**.

> `</>` Developed by **MD Huzaifa**

## Features

- Pick a date of birth and any "age at" date (defaults to today)
- Exact age in years / months / days
- Totals: months, weeks, days, hours, minutes
- Next birthday countdown and weekday
- Zodiac sign
- Dark gradient UI, fully offline, no permissions required

## Build the APK with GitHub Actions

1. Push this project to a GitHub repository (branch `main`).
2. Open the **Actions** tab and wait for **Build Android APK** to finish (or run it manually with *Run workflow*).
3. Open the finished run and download the **AgeCalculator-release** (or **-debug**) artifact.
4. Unzip it and install the `.apk` on your Android phone.

## Build locally

Requires Android Studio (Koala or newer) or JDK 17 + Android SDK 34.

```bash
gradle assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```

## Project structure

```
app/src/main/java/com/mdhuzaifa/agecalculator/
├── MainActivity.kt        # entry point
├── AgeCalculator.kt       # age logic (java.time)
└── ui/
    ├── AgeScreen.kt       # screen, date pickers, results
    └── theme/Theme.kt     # colors and Material 3 theme
```

## Note on signing

The release build is signed with the debug key so it installs directly. Before publishing to Google Play, create your own keystore and update `app/build.gradle.kts`.

---

© MD Huzaifa
