package com.mdhuzaifa.agecalculator.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Ink = Color(0xFF0B1020)
val Indigo = Color(0xFF1B1446)
val Panel = Color(0xFF151A33)
val Violet = Color(0xFF7C5CFF)
val Cyan = Color(0xFF22D3EE)
val Pink = Color(0xFFF472B6)
val TextHigh = Color(0xFFF1F3FF)
val TextMuted = Color(0xFFA7ADCC)

private val Scheme = darkColorScheme(
    primary = Violet,
    onPrimary = Color.White,
    secondary = Cyan,
    onSecondary = Ink,
    tertiary = Pink,
    background = Ink,
    onBackground = TextHigh,
    surface = Panel,
    onSurface = TextHigh,
    surfaceVariant = Color(0xFF222850),
    onSurfaceVariant = TextMuted,
    outline = Color(0xFF3A4170),
)

@Composable
fun AgeCalculatorTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
