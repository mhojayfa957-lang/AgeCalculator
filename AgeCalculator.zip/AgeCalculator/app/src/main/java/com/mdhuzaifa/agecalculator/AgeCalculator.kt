package com.mdhuzaifa.agecalculator

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.Period
import java.time.temporal.ChronoUnit

/** Everything the UI needs to display after a calculation. */
data class AgeResult(
    val years: Int,
    val months: Int,
    val days: Int,
    val totalMonths: Long,
    val totalWeeks: Long,
    val totalDays: Long,
    val totalHours: Long,
    val totalMinutes: Long,
    val nextBirthday: LocalDate,
    val daysUntilBirthday: Long,
    val birthWeekday: DayOfWeek,
    val zodiac: String,
)

object AgeCalculator {

    /**
     * Calculates the exact age between [birth] and [target].
     * [birth] must not be after [target].
     */
    fun calculate(birth: LocalDate, target: LocalDate): AgeResult {
        require(!birth.isAfter(target)) { "Birth date cannot be after the target date." }

        val period = Period.between(birth, target)
        val totalDays = ChronoUnit.DAYS.between(birth, target)

        // withYear() safely maps Feb 29 to Feb 28 in non-leap years.
        var next = birth.withYear(target.year)
        if (next.isBefore(target)) next = birth.withYear(target.year + 1)

        return AgeResult(
            years = period.years,
            months = period.months,
            days = period.days,
            totalMonths = period.toTotalMonths(),
            totalWeeks = totalDays / 7,
            totalDays = totalDays,
            totalHours = totalDays * 24,
            totalMinutes = totalDays * 24 * 60,
            nextBirthday = next,
            daysUntilBirthday = ChronoUnit.DAYS.between(target, next),
            birthWeekday = birth.dayOfWeek,
            zodiac = zodiacOf(birth),
        )
    }

    fun zodiacOf(date: LocalDate): String {
        val m = date.monthValue
        val d = date.dayOfMonth
        return when {
            (m == 3 && d >= 21) || (m == 4 && d <= 19) -> "♈ Aries"
            (m == 4 && d >= 20) || (m == 5 && d <= 20) -> "♉ Taurus"
            (m == 5 && d >= 21) || (m == 6 && d <= 20) -> "♊ Gemini"
            (m == 6 && d >= 21) || (m == 7 && d <= 22) -> "♋ Cancer"
            (m == 7 && d >= 23) || (m == 8 && d <= 22) -> "♌ Leo"
            (m == 8 && d >= 23) || (m == 9 && d <= 22) -> "♍ Virgo"
            (m == 9 && d >= 23) || (m == 10 && d <= 22) -> "♎ Libra"
            (m == 10 && d >= 23) || (m == 11 && d <= 21) -> "♏ Scorpio"
            (m == 11 && d >= 22) || (m == 12 && d <= 21) -> "♐ Sagittarius"
            (m == 12 && d >= 22) || (m == 1 && d <= 19) -> "♑ Capricorn"
            (m == 1 && d >= 20) || (m == 2 && d <= 18) -> "♒ Aquarius"
            else -> "♓ Pisces"
        }
    }
}
