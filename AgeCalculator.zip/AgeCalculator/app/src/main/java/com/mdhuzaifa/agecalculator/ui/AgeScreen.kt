package com.mdhuzaifa.agecalculator.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mdhuzaifa.agecalculator.AgeCalculator
import com.mdhuzaifa.agecalculator.AgeResult
import com.mdhuzaifa.agecalculator.ui.theme.Cyan
import com.mdhuzaifa.agecalculator.ui.theme.Indigo
import com.mdhuzaifa.agecalculator.ui.theme.Ink
import com.mdhuzaifa.agecalculator.ui.theme.Pink
import com.mdhuzaifa.agecalculator.ui.theme.TextHigh
import com.mdhuzaifa.agecalculator.ui.theme.TextMuted
import com.mdhuzaifa.agecalculator.ui.theme.Violet
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

private val DateFormat: DateTimeFormatter =
    DateTimeFormatter.ofPattern("dd MMMM yyyy", Locale.ENGLISH)

private fun Long.fmt(): String = String.format(Locale.US, "%,d", this)

@Composable
fun AgeScreen() {
    var birthEpoch by rememberSaveable { mutableStateOf<Long?>(null) }
    var targetEpoch by rememberSaveable { mutableLongStateOf(LocalDate.now().toEpochDay()) }
    var showResult by rememberSaveable { mutableStateOf(false) }
    var error by rememberSaveable { mutableStateOf<String?>(null) }
    var pickBirth by remember { mutableStateOf(false) }
    var pickTarget by remember { mutableStateOf(false) }

    val birth = birthEpoch?.let { LocalDate.ofEpochDay(it) }
    val target = LocalDate.ofEpochDay(targetEpoch)

    val result: AgeResult? = remember(showResult, birthEpoch, targetEpoch) {
        if (showResult && birth != null && !birth.isAfter(target)) {
            AgeCalculator.calculate(birth, target)
        } else null
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Ink, Indigo, Ink)))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 16.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Header()

            // ---- Input card ----
            GlassCard {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    DateField(
                        label = "Date of Birth",
                        value = birth?.format(DateFormat) ?: "Select your birth date",
                        isPlaceholder = birth == null,
                        onClick = { pickBirth = true },
                    )
                    DateField(
                        label = "Age at the Date of",
                        value = target.format(DateFormat),
                        isPlaceholder = false,
                        onClick = { pickTarget = true },
                    )

                    error?.let {
                        Text(
                            text = it,
                            color = Pink,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Button(
                            onClick = {
                                when {
                                    birth == null -> {
                                        error = "Please select your date of birth."
                                        showResult = false
                                    }
                                    birth.isAfter(target) -> {
                                        error = "Date of birth cannot be after the age-at date."
                                        showResult = false
                                    }
                                    else -> {
                                        error = null
                                        showResult = true
                                    }
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(52.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Violet),
                        ) {
                            Text("Calculate Age", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                        OutlinedButton(
                            onClick = {
                                birthEpoch = null
                                targetEpoch = LocalDate.now().toEpochDay()
                                showResult = false
                                error = null
                            },
                            modifier = Modifier.height(52.dp),
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        ) {
                            Text("Reset", color = TextHigh)
                        }
                    }
                }
            }

            // ---- Results ----
            AnimatedVisibility(
                visible = result != null,
                enter = fadeIn() + expandVertically(),
                exit = ExitTransition.None,
            ) {
                result?.let { ResultSection(it, target) }
            }

            Spacer(Modifier.height(4.dp))
            DeveloperFooter()
            Spacer(Modifier.height(8.dp))
        }
    }

    if (pickBirth) {
        DateDialog(
            initial = birth,
            onDismiss = { pickBirth = false },
            onPick = {
                birthEpoch = it.toEpochDay()
                showResult = false
                error = null
            },
        )
    }
    if (pickTarget) {
        DateDialog(
            initial = target,
            onDismiss = { pickTarget = false },
            onPick = {
                targetEpoch = it.toEpochDay()
                showResult = false
                error = null
            },
        )
    }
}

@Composable
private fun Header() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("🎂", fontSize = 44.sp)
        Spacer(Modifier.height(6.dp))
        Text(
            text = "Age Calculator",
            color = TextHigh,
            fontSize = 30.sp,
            fontWeight = FontWeight.ExtraBold,
        )
        Text(
            text = "Find your exact age in years, months and days",
            color = TextMuted,
            fontSize = 14.sp,
            textAlign = TextAlign.Center,
        )
    }
}

@Composable
private fun GlassCard(content: @Composable () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        color = Color.White.copy(alpha = 0.06f),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.10f)),
    ) {
        Box(Modifier.padding(18.dp)) { content() }
    }
}

@Composable
private fun DateField(
    label: String,
    value: String,
    isPlaceholder: Boolean,
    onClick: () -> Unit,
) {
    Column {
        Text(
            text = label,
            color = TextMuted,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(start = 4.dp, bottom = 6.dp),
        )
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .clickable(onClick = onClick),
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surfaceVariant,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 15.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("📅", fontSize = 18.sp)
                Spacer(Modifier.padding(horizontal = 6.dp))
                Text(
                    text = value,
                    color = if (isPlaceholder) TextMuted else TextHigh,
                    fontSize = 16.sp,
                    fontWeight = if (isPlaceholder) FontWeight.Normal else FontWeight.Medium,
                )
            }
        }
    }
}

@Composable
private fun ResultSection(r: AgeResult, target: LocalDate) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // Hero card with the exact age
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(28.dp),
            color = Color.Transparent,
        ) {
            Box(
                modifier = Modifier
                    .background(Brush.linearGradient(listOf(Violet, Color(0xFF4F46E5), Cyan)))
                    .padding(vertical = 22.dp, horizontal = 12.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "YOUR AGE",
                        color = Color.White.copy(alpha = 0.85f),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp,
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(modifier = Modifier.fillMaxWidth()) {
                        BigStat(r.years.toString(), "Years", Modifier.weight(1f))
                        BigStat(r.months.toString(), "Months", Modifier.weight(1f))
                        BigStat(r.days.toString(), "Days", Modifier.weight(1f))
                    }
                }
            }
        }

        // Next birthday
        GlassCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("🎉", fontSize = 30.sp)
                Spacer(Modifier.padding(horizontal = 8.dp))
                Column {
                    Text(
                        text = if (r.daysUntilBirthday == 0L) "Happy Birthday! 🥳"
                        else "Next birthday in ${r.daysUntilBirthday.fmt()} days",
                        color = TextHigh,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                    )
                    Text(
                        text = r.nextBirthday.format(DateFormat) + " • " +
                            r.nextBirthday.dayOfWeek.getDisplayName(TextStyle.FULL, Locale.ENGLISH),
                        color = TextMuted,
                        fontSize = 13.sp,
                    )
                }
            }
        }

        // Totals
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile("Total Months", r.totalMonths.fmt(), Modifier.weight(1f))
            StatTile("Total Weeks", r.totalWeeks.fmt(), Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile("Total Days", r.totalDays.fmt(), Modifier.weight(1f))
            StatTile("Total Hours", r.totalHours.fmt(), Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile("Total Minutes", r.totalMinutes.fmt(), Modifier.weight(1f))
            StatTile(
                "Born on",
                r.birthWeekday.getDisplayName(TextStyle.FULL, Locale.ENGLISH),
                Modifier.weight(1f),
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile("Zodiac Sign", r.zodiac, Modifier.weight(1f))
            StatTile("Age at", target.format(DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.ENGLISH)), Modifier.weight(1f))
        }
    }
}

@Composable
private fun BigStat(value: String, label: String, modifier: Modifier = Modifier) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            color = Color.White,
            fontSize = 44.sp,
            fontWeight = FontWeight.ExtraBold,
        )
        Text(
            text = label,
            color = Color.White.copy(alpha = 0.85f),
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
        )
    }
}

@Composable
private fun StatTile(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        color = Color.White.copy(alpha = 0.06f),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.10f)),
    ) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) {
            Text(label, color = TextMuted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text(value, color = TextHigh, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun DeveloperFooter() {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Surface(
            shape = RoundedCornerShape(50),
            color = Color.White.copy(alpha = 0.06f),
            border = BorderStroke(1.dp, Cyan.copy(alpha = 0.45f)),
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = "</>",
                    color = Cyan,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.ExtraBold,
                )
                Spacer(Modifier.padding(horizontal = 5.dp))
                Text(
                    text = "Developed by MD Huzaifa",
                    color = TextHigh,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Text("Age Calculator • v1.0.0", color = TextMuted, fontSize = 11.sp)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DateDialog(
    initial: LocalDate?,
    onDismiss: () -> Unit,
    onPick: (LocalDate) -> Unit,
) {
    val state = rememberDatePickerState(
        initialSelectedDateMillis = initial
            ?.atStartOfDay(ZoneOffset.UTC)
            ?.toInstant()
            ?.toEpochMilli()
    )
    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = {
                state.selectedDateMillis?.let { ms ->
                    onPick(Instant.ofEpochMilli(ms).atZone(ZoneOffset.UTC).toLocalDate())
                }
                onDismiss()
            }) { Text("OK") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    ) {
        DatePicker(state = state)
    }
}
